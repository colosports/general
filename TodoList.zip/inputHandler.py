#!/usr/bin/python3

# import library if needed

# read input from file. 

# validate input

# Reading an excel file using Python
import xlrd

# Give the location of the file
loc = ("C:\WAPT\TodoList\records.xls")

def readInput():
    # To open Workbook
    wb = xlrd.open_workbook(loc)
    sheet = wb.sheet_by_index(0)
    # For row 0 and column 0
    print(sheet.cell_value(0, 0))

def main():
    print ("Starting script")
    readInput()    

if __name__ == '__main__':
    main()
