<?php
session_start();

echo "Session ID: " . session_id() . "<hr/>";
if(!isset($_SESSION["admin"]))
{
    echo "<h1 style='color: red;'>You are not authorized to view this page.</h1> <a href='index.php'>Back to login</a>";
}
else
{ 
    //echo "<h2>You are logged in as " . $_SESSION["admin"]["user"] . " and you have been granted access.</h2>";
?>
<!doctype html>
<html lang="en">
  <head>
    <title>Banker &mdash; Website Template by Colorlib</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">    
    
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,700" rel="stylesheet">

    <link rel="stylesheet" href="/banker/css/bootstrap.min.css">
    <link rel="stylesheet" href="/banker/css/owl.carousel.min.css">
    <link rel="stylesheet" href="/banker/css/style.css">
    
  </head>
  <body data-spy="scroll" data-target=".site-navbar-target" data-offset="300">
  

  <div id="overlayer"></div>


  <div class="site-wrap">

    <div class="site-mobile-menu site-navbar-target">
      <div class="site-mobile-menu-header">
        <div class="site-mobile-menu-close mt-3">
          <span class="icon-close2 js-menu-toggle"></span>
        </div>
      </div>
      <div class="site-mobile-menu-body"></div>
    </div>
   
    
    <header class="site-navbar js-sticky-header site-navbar-target" role="banner">

      <div class="container">
        <div class="row align-items-center">
          
          <div class="col-6 col-xl-2">
            <h1 class="mb-0 site-logo"><a href="index.html" class="h2 mb-0">Banker<span class="text-primary">.</span> </a></h1>
          </div>

          <div class="col-12 col-md-10 d-none d-xl-block">
            <nav class="site-navigation position-relative text-right" role="navigation">

              <ul class="site-menu main-menu js-clone-nav mr-auto d-none d-lg-block">
                <li><a href="index.html#home-section" class="nav-link">Home</a></li>
                <li class="has-children">
                  <a href="index.html#about-section" class="nav-link">About Us</a>
                  <ul class="dropdown">
                    <li><a href="index.html#team-section" class="nav-link">Team</a></li>
                    <li><a href="index.html#pricing-section" class="nav-link">Pricing</a></li>
                    <li><a href="index.html#faq-section" class="nav-link">FAQ</a></li>
                    <li><a href="index.html#gallery-section" class="nav-link">Gallery</a></li>
                    <li><a href="index.html#services-section" class="nav-link">Services</a></li>
                    <li><a href="index.html#testimonials-section" class="nav-link">Testimonials</a></li>
                    <li class="has-children">
                      <a href="#">More Links</a>
                      <ul class="dropdown">
                        <li><a href="#">Menu One</a></li>
                        <li><a href="#">Menu Two</a></li>
                        <li><a href="#">Menu Three</a></li>
                      </ul>
                    </li>
                  </ul>
                </li>
                
                
                <li><a href="index.html#blog-section" class="nav-link">Blog</a></li>
                <li><a href="index.html#contact-section" class="nav-link">Contact</a></li>
                <li class="social"><a href="index.html#contact-section" class="nav-link"><span class="icon-facebook"></span></a></li>
                <li class="social"><a href="index.html#contact-section" class="nav-link"><span class="icon-twitter"></span></a></li>
                <li class="social"><a href="index.html#contact-section" class="nav-link"><span class="icon-linkedin"></span></a></li>
                <li class="social"><a href="logout.php" class="nav-link"><span class="icon-linkedin">Log Out</span></a></li>
              </ul>
            </nav>
          </div>


          <div class="col-6 d-inline-block d-xl-none ml-md-0 py-3" style="position: relative; top: 3px;"><a href="#" class="site-menu-toggle js-menu-toggle float-right"><span class="icon-menu h3"></span></a></div>

        </div>
      </div>       
      <div>
      <hr />
  <div >
<table cellspacing="0" width="100%">

    <td valign="top" class="cc br bb">
    <br />
    <br />
    <br />
    <br />
    <br />
    <br />
    <br />
        <br style="line-height: 10px;"/>
        <b>I WANT TO ...</b>
        <ul class="sidebar">
            <li><a id="MenuHyperLink1" href="/bank/main.jsp">View Account Summary</a></li>
            <li><a id="MenuHyperLink2" href="/bank/transaction.jsp">View Recent Transactions</a></li>
            <li><a id="MenuHyperLink3" href="/bank/transfer.jsp">Transfer Funds</a></li>
        <!-- <li><a id="MenuHyperLink3" href="/bank/stocks.jsp">Trade Stocks</a></li>-->
            
            <li><a id="MenuHyperLink4" href="/bank/queryxpath.jsp">Search News Articles</a></li>
            <li><a id="MenuHyperLink5" href="/bank/customize.jsp">Customize Site Language</a></li>
        </ul>
    
    <span id="_ctl0__ctl0_Content_Administration">
        <br style="line-height: 10px;"/>
        <b>ADMINISTRATION</b>
        <ul class="sidebar">
            <li><a href="/admin/admin.jsp">Edit Users</a></li>
            
        </ul>
    </span>
    
    </td>
<!-- MEMBER TOC END -->
    <td valign="top" colspan="3" class="bb">    
        <div class="fl" style="width: 99%;">
        
        
        
        <!-- To modify account information do not connect to SQL source directly.  Make all changes
        through the admin page. -->
        
    <br />
    <br />
        <h1>Account History - 8023845</h1>
        
    <br />
    <br />
    <br />
        <table width="590" border="0">
            <tr>
                <td colspan=2>
                    <table cellSpacing="0" cellPadding="1" width="100%" border="1">
                    <tr>
                        <th colSpan="2">
                        Balance Detail</th></tr>
                    <tr>
                        <th align="left" width="80%" height="26">
                        <form id="Form1" method="get" action="showAccount">
                            <select size="1" name="listAccounts" id="listAccounts">
                            <option value="800000">8023845 Checking</option>
    <option value="800001">9543567 Savings</option>

                        </select>
                            <input type="submit" id="btnGetAccount" Value="Select Account">
                        </FORM>
                        </th>
                        <th align="middle" height="26">
                        Amount
                        </th>
                    </tr>
                    <tr>
                        <td>Ending balance as of 7/13/20 5:09 AM
                        </td>
                        <td align="right">$3,244.00
    </td>
                    </tr>
                        <tr>
                        <td>Available balance
                        </td>
                        <td align="right">
                        $2,976.43
    </td>
                    </tr>
                    </table>
                </td>
            </tr>
            <tr>
                <td>
                    <br><b>10 Most Recent Transactions</b><table border=1 cellpadding=2 cellspacing=0 width='590'><tr><th bgcolor=#cccccc width=100>Date </th><th width=290>Description</th><th width=100>Amount</th></tr></table><DIV ID='recent' STYLE='overflow: hidden; overflow-y: scroll; width:590px; height: 175px; padding:0px; margin: 0px' ><table border=1 cellpadding=2 cellspacing=0 width='574'>
                    
                    <tr><td width=99>2020-07-13</td><td width=292>Withdrawal</td><td width=84 align=right>-$200.00</td></tr>
                    
                    <tr><td width=99>2020-07-13</td><td width=292>Deposit</td><td width=84 align=right>$1234.00</td></tr>
                    
                    <tr><td width=99>2018-06-11</td><td width=292>Withdrawal</td><td width=84 align=right>-$10.00</td></tr>
                    
                    <tr><td width=99>2018-05-15</td><td width=292>Withdrawal</td><td width=84 align=right>-$10.00</td></tr>
                    
                    <tr><td width=99>2018-04-14</td><td width=292>Withdrawal</td><td width=84 align=right>-$10.00</td></tr>
                    
                    <tr><td width=99>2018-01-10</td><td width=292>Deposit</td><td width=84 align=right>$100.00</td></tr>
                    
                    </table></DIV>
                </td>
            </tr>

            <tr>
                <td>
                    <br><b>Debits</b><table border=1 cellpadding=2 cellspacing=0 width='590'><tr><th width=100>Account<th bgcolor=#cccccc width=100>Date </th><th width=290>Description</th><th width=100>Amount</th></tr></table><DIV ID='debits' STYLE='overflow: hidden; overflow-y: scroll; width:590px; height: 300px; padding:0px; margin: 0px' ><table border=1 cellpadding=2 cellspacing=0 width='574'><tr><td width=99>1001160140</td><td width=99>01/17/2005</td><td width=292>Withdrawal</td><td width=84 align=right>2.85</td></tr><tr><td width=99>1001160140</td><td width=99>01/25/2005</td><td width=292>Rent</td><td width=84 align=right>800</td></tr><tr><td width=99>1001160140</td><td width=99>01/25/2005</td><td width=292>Electric Bill</td><td width=84 align=right>45.25</td></tr><tr><td width=99>1001160140</td><td width=99>01/25/2005</td><td width=292>Heating</td><td width=84 align=right>29.99</td></tr><tr><td width=99>1001160140</td><td width=99>01/29/2005</td><td width=292>Transfer to Savings</td><td width=84 align=right>321</td></tr>
                <tr><td width=99>1001160140</td><td width=99>01/29/2005</td><td width=292>Groceries</td><td width=84 align=right>19.6</td></tr><tr><td width=99>1001160140</td><td width=99>01/30/2005</td><td width=292>Entertainment</td><td width=84 align=right>44.16</td></tr><tr><td width=99>1001160140</td><td width=99>02/01/2005</td><td width=292>Car Repair</td><td width=84 align=right>83.05</td></tr><tr><td width=99>1001160140</td><td width=99>02/03/2005</td><td width=292>Entertainment</td><td width=84 align=right>29.54</td></tr><tr><td width=99>1001160140</td><td width=99>02/04/2005</td><td width=292>Withdrawal</td><td width=84 align=right>81.57</td></tr><tr><td width=99>1001160140</td><td width=99>02/06/2005</td><td width=292>Groceries</td><td width=84 align=right>90.26</td></tr><tr><td width=99>1001160140</td><td width=99>02/12/2005</td><td width=292>Groceries</td><td width=84 align=right>85.12</td></tr><tr><td width=99>1001160140</td><td width=99>02/23/2005</td><td width=292>Withdrawal</td><td width=84 align=right>32.31</td></tr>
                <tr><td width=99>1001160140</td><td width=99>02/25/2005</td><td width=292>Rent</td><td width=84 align=right>800</td></tr><tr><td width=99>1001160140</td><td width=99>02/25/2005</td><td width=292>Electric Bill</td><td width=84 align=right>45.25</td></tr><tr><td width=99>1001160140</td><td width=99>02/25/2005</td><td width=292>Heating</td><td width=84 align=right>29.99</td></tr><tr><td width=99>1001160140</td><td width=99>03/01/2005</td><td width=292>Transfer to Savings</td><td width=84 align=right>1060</td></tr><tr><td width=99>1001160140</td><td width=99>03/04/2005</td><td width=292>Transportation</td><td width=84 align=right>15.47</td></tr><tr><td width=99>1001160140</td><td width=99>03/05/2005</td><td width=292>Withdrawal</td><td width=84 align=right>63.13</td></tr>
                
                </table></DIV>
                </td>
            </tr>
        </table>		
        </div>
    </td>
</table>
</div>    
      
      
      
      
      
      
      </div>
    </header> 
    </div>  




    
    <footer class="site-footer">
    </footer>

  </div> <!-- .site-wrap -->

  <script src="js/jquery-3.3.1.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/owl.carousel.min.js"></script>
  <script src="js/jquery.countdown.min.js"></script>
  <script src="js/aos.js"></script>
  <script src="js/jquery.sticky.js"></script>  
  <script src="js/main.js"></script>

  </body>
</html>
<?php
}
?>

