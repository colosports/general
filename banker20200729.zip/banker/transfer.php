<?php
session_start();

// echo "Session ID: " . session_id() . "<hr/>";
if(!isset($_SESSION["admin"]))
{
    echo "<h1 style='color: red;'>You are not authorized to view this page.</h1> <a href='index.php'>Back to login</a>";
}
else
{ 
    //echo "<h2>You are logged in as " . $_SESSION["admin"]["user"] . " and you have been granted access.</h2>";
?>
<!doctype html>
<html lang="en">
  <head>
    <title>Banker &mdash; Website Template by Colorlib</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">    
    
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,700" rel="stylesheet">

    <link rel="stylesheet" href="/banker/css/bootstrap.min.css">
    <link rel="stylesheet" href="/banker/css/owl.carousel.min.css">
    <link rel="stylesheet" href="/banker/css/style.css">
    
  </head>
  <body data-spy="scroll" data-target=".site-navbar-target" data-offset="300">
  

  <div id="overlayer"></div>


  <div class="site-wrap">

    <div class="site-mobile-menu site-navbar-target">
      <div class="site-mobile-menu-header">
        <div class="site-mobile-menu-close mt-3">
          <span class="icon-close2 js-menu-toggle"></span>
        </div>
      </div>
      <div class="site-mobile-menu-body"></div>
    </div>
   
    
    <header class="site-navbar js-sticky-header site-navbar-target" role="banner">

      <div class="container">
        <div class="row align-items-center">
          
          <div class="col-6 col-xl-2">
            <h1 class="mb-0 site-logo"><a href="index.html" class="h2 mb-0">Banker<span class="text-primary">.</span> </a></h1>
          </div>

          <div class="col-12 col-md-10 d-none d-xl-block">
            <nav class="site-navigation position-relative text-right" role="navigation">

              <ul class="site-menu main-menu js-clone-nav mr-auto d-none d-lg-block">
                <li><a href="index.html#home-section" class="nav-link">Home</a></li>
                <li class="has-children">
                  <a href="index.html#about-section" class="nav-link">About Us</a>
                  <ul class="dropdown">
                    <li><a href="index.html#team-section" class="nav-link">Team</a></li>
                    <li><a href="index.html#pricing-section" class="nav-link">Pricing</a></li>
                    <li><a href="index.html#faq-section" class="nav-link">FAQ</a></li>
                    <li><a href="index.html#gallery-section" class="nav-link">Gallery</a></li>
                    <li><a href="index.html#services-section" class="nav-link">Services</a></li>
                    <li><a href="index.html#testimonials-section" class="nav-link">Testimonials</a></li>
                    <li class="has-children">
                      <a href="#">More Links</a>
                      <ul class="dropdown">
                        <li><a href="#">Menu One</a></li>
                        <li><a href="#">Menu Two</a></li>
                        <li><a href="#">Menu Three</a></li>
                      </ul>
                    </li>
                  </ul>
                </li>
                
                
                <li><a href="index.html#blog-section" class="nav-link">Blog</a></li>
                <li><a href="index.html#contact-section" class="nav-link">Contact</a></li>
                <li class="social"><a href="index.html#contact-section" class="nav-link"><span class="icon-facebook"></span></a></li>
                <li class="social"><a href="index.html#contact-section" class="nav-link"><span class="icon-twitter"></span></a></li>
                <li class="social"><a href="index.html#contact-section" class="nav-link"><span class="icon-linkedin"></span></a></li>
                <li class="social"><a href="logout.php" class="nav-link"><span class="icon-linkedin">Log Out</span></a></li>
              </ul>
            </nav>
          </div>


          <div class="col-6 d-inline-block d-xl-none ml-md-0 py-3" style="position: relative; top: 3px;"><a href="#" class="site-menu-toggle js-menu-toggle float-right"><span class="icon-menu h3"></span></a></div>

        </div>
      </div>       
      <div>
      <hr />
  <div >
<table cellspacing="0" width="100%">

    <td valign="top" class="cc br bb">
    <br />
    <br />
    <br />
    <br />
    <br />
    <br />
    <br />
        <br style="line-height: 10px;"/>
        <b>I WANT TO ...</b>
        <ul class="sidebar">
            <li><a id="MenuHyperLink1" href="/main.php">View Account Summary</a></li>
            <li><a id="MenuHyperLink2" href="/transaction.php">View Recent Transactions</a></li>
            <li><a id="MenuHyperLink3" href="/transfer.php">Transfer Funds</a></li>
            <li><a id="MenuHyperLink3" href="/stocks.php">Trade Stocks</a></li>
            
        </ul>
    
    <span id="_ctl0__ctl0_Content_Administration">
        <br style="line-height: 10px;"/>
        <b>ADMINISTRATION</b>
        <ul class="sidebar">
            <li><a href="/admin/admin.jsp">Edit Users</a></li>
            
        </ul>
    </span>
    
    </td>
<!-- MEMBER TOC END -->
    <td valign="top" colspan="3" class="bb">    
        <div class="fl" style="width: 99%;">
        
        
        
        <!-- To modify account information do not connect to SQL source directly.  Make all changes
        through the admin page. -->
        
    <br />
    <br />
        <h1>Account History - 8023845</h1>
        
    <br />
    <br />
    <br />
        <table width="590" border="0">                    
                    <tr>
                        <td>Ending balance as of 7/13/20 5:09 AM
                        </td>
                        <td align="right">$3,244.00
    </td>
                    </tr>
                        <tr>
                        <td>Available balance
                        </td>
                        <td align="right">
                        $2,976.43
    </td>
                    </tr>
                                
            <tr>
                <td colspan=2>
                    <table cellSpacing="0" cellPadding="1" width="100%" border="1">
                    <tr>
                        <th colSpan="2">
                        Transfer Funds</th></tr>
                    <tr>
                        <th align="left" width="80%" height="26">

													<form action="transfer_successful.php" method="post">
															Transfer Funds from: 
															<select size="1" name="listAccounts" id="listAccounts">
																<option value="800000">8023845 Checking</option>
																<option value="800001">9543567 Savings</option>
															</select><br />
															Transfer Funds to: 
															Bank ABA: <input type="password" name="aba" /><br />
															Bank Account #: <input type="password" name="account1" /><br />
															Confirm Bank Account #: <input type="password" name="account2" /><br />
															Transfer Amount: $<input type="test" name="amount" /><br />
															<input type="submit" value="Transfer" />
													</form>
                        </th>
                    </tr>

                    </table>
                </td>
            </tr>
            
            



                
                </table></DIV>
                </td>
            </tr>
        </table>		
        </div>
    </td>
</table>
</div>    
      
      
      
      
      
      
      </div>
    </header> 
    </div>  




    
    <footer class="site-footer">
    </footer>

  </div> <!-- .site-wrap -->

  <script src="js/jquery-3.3.1.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/owl.carousel.min.js"></script>
  <script src="js/jquery.countdown.min.js"></script>
  <script src="js/aos.js"></script>
  <script src="js/jquery.sticky.js"></script>  
  <script src="js/main.js"></script>

  </body>
</html>
<?php
}
?>

